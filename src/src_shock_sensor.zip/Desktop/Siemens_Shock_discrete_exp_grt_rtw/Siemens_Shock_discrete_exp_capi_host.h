#ifndef RTW_HEADER_Siemens_Shock_discrete_exp_cap_host_h_
#define RTW_HEADER_Siemens_Shock_discrete_exp_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"

typedef struct {
  rtwCAPI_ModelMappingInfo mmi;
} Siemens_Shock_discrete_exp_host_DataMapInfo_T;

#ifdef __cplusplus

extern "C" {

#endif

  void Siemens_Shock_discrete_exp_host_InitializeDataMapInfo
    (Siemens_Shock_discrete_exp_host_DataMapInfo_T *dataMap, const char *path);

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */
#endif                                 /* RTW_HEADER_Siemens_Shock_discrete_exp_cap_host_h_ */

/* EOF: Siemens_Shock_discrete_exp_capi_host.h */
