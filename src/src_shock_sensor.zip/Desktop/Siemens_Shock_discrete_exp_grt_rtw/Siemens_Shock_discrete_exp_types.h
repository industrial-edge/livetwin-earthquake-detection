/*
 * Siemens_Shock_discrete_exp_types.h
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.92
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C++ source code generated on : Mon Nov 25 15:24:20 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Siemens_Shock_discrete_exp_types_h_
#define RTW_HEADER_Siemens_Shock_discrete_exp_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (default storage) */
typedef struct P_Siemens_Shock_discrete_exp_T_ P_Siemens_Shock_discrete_exp_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_Siemens_Shock_discret_T RT_MODEL_Siemens_Shock_discre_T;

#endif                                 /* RTW_HEADER_Siemens_Shock_discrete_exp_types_h_ */
