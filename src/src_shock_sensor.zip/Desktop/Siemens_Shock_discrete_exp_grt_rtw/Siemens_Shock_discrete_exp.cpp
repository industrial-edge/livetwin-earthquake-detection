/*
 * Siemens_Shock_discrete_exp.cpp
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.92
 * Simulink Coder version : 9.0 (R2018b) 24-May-2018
 * C++ source code generated on : Mon Nov 25 15:24:20 2019
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Siemens_Shock_discrete_exp_capi.h"
#include "Siemens_Shock_discrete_exp.h"
#include "Siemens_Shock_discrete_exp_private.h"

/* Model step function */
void Siemens_Shock_discrete_expModelClass::step()
{
  real_T rtb_Beschleunigung;

  /* Constant: '<S2>/h_Auflage' */
  Siemens_Shock_discrete_exp_B.h_Auflage =
    Siemens_Shock_discrete_exp_P.h_Auflage;

  /* DiscreteIntegrator: '<S2>/Discrete-Time Integrator2' */
  if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE >=
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa;
  } else {
    if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE <=
        Siemens_Shock_discrete_exp_P.h_Auflage) {
      Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
        Siemens_Shock_discrete_exp_P.h_Auflage;
    }
  }

  /* Outport: '<Root>/phi' incorporates:
   *  DiscreteIntegrator: '<S2>/Discrete-Time Integrator2'
   */
  Siemens_Shock_discrete_exp_Y.phi =
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE;

  /* Outport: '<Root>/Schock' incorporates:
   *  Constant: '<S3>/Constant'
   *  DiscreteIntegrator: '<S2>/Discrete-Time Integrator2'
   *  RelationalOperator: '<S3>/Compare'
   */
  Siemens_Shock_discrete_exp_Y.Schock =
    (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE >=
     Siemens_Shock_discrete_exp_P.max_angle);

  /* Gain: '<S2>/J' incorporates:
   *  Constant: '<S2>/g'
   *  Constant: '<S2>/r_Kugel'
   *  DiscreteIntegrator: '<S2>/Discrete-Time Integrator2'
   *  Inport: '<Root>/Accel x'
   *  Inport: '<Root>/Accel y'
   *  Math: '<S1>/Math Function'
   *  Math: '<S1>/Math Function1'
   *  Product: '<S2>/Divide'
   *  Product: '<S2>/Product'
   *  Product: '<S2>/Product1'
   *  Product: '<S2>/Product2'
   *  Sqrt: '<S1>/Sqrt'
   *  Sum: '<S1>/Add'
   *  Sum: '<S2>/Add'
   *  Trigonometry: '<S2>/Trigonometric Function'
   *  Trigonometry: '<S2>/Trigonometric Function1'
   *
   * About '<S1>/Math Function':
   *  Operator: magnitude^2
   *
   * About '<S1>/Math Function1':
   *  Operator: magnitude^2
   */
  rtb_Beschleunigung = (Siemens_Shock_discrete_exp_P.dK / 2.0 * std::sin
                        (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE)
                        * std::sqrt(Siemens_Shock_discrete_exp_U.Accelx *
    Siemens_Shock_discrete_exp_U.Accelx + Siemens_Shock_discrete_exp_U.Accely *
    Siemens_Shock_discrete_exp_U.Accely) - Siemens_Shock_discrete_exp_P.dK / 2.0
                        * std::cos
                        (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE)
                        * Siemens_Shock_discrete_exp_P.g) * (1.0 /
    Siemens_Shock_discrete_exp_P.J_Kugel);

  /* DiscreteIntegrator: '<S2>/Discrete-Time Integrator' */
  if ((rtb_Beschleunigung > 0.0) &&
      (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese <= 0)) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_DSTATE =
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator_IC;
  }

  /* Update for DiscreteIntegrator: '<S2>/Discrete-Time Integrator2' incorporates:
   *  DiscreteIntegrator: '<S2>/Discrete-Time Integrator'
   */
  Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE +=
    Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_gainval *
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_DSTATE;
  if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE >=
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa;
  } else {
    if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE <=
        Siemens_Shock_discrete_exp_P.h_Auflage) {
      Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
        Siemens_Shock_discrete_exp_P.h_Auflage;
    }
  }

  /* End of Update for DiscreteIntegrator: '<S2>/Discrete-Time Integrator2' */

  /* Update for DiscreteIntegrator: '<S2>/Discrete-Time Integrator' */
  Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_DSTATE +=
    Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator_gainval *
    rtb_Beschleunigung;
  if (rtb_Beschleunigung > 0.0) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese = 1;
  } else if (rtb_Beschleunigung < 0.0) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese = -1;
  } else if (rtb_Beschleunigung == 0.0) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese = 0;
  } else {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese = 2;
  }

  /* End of Update for DiscreteIntegrator: '<S2>/Discrete-Time Integrator' */
}

/* Model initialize function */
void Siemens_Shock_discrete_expModelClass::initialize()
{
  /* Registration code */

  /* initialize real-time model */
  (void) memset((void *)(&Siemens_Shock_discrete_exp_M), 0,
                sizeof(RT_MODEL_Siemens_Shock_discre_T));

  /* block I/O */
  (void) memset(((void *) &Siemens_Shock_discrete_exp_B), 0,
                sizeof(B_Siemens_Shock_discrete_exp_T));

  /* states (dwork) */
  (void) memset((void *)&Siemens_Shock_discrete_exp_DW, 0,
                sizeof(DW_Siemens_Shock_discrete_exp_T));

  /* external inputs */
  (void)memset(&Siemens_Shock_discrete_exp_U, 0, sizeof
               (ExtU_Siemens_Shock_discrete_e_T));

  /* external outputs */
  (void) memset((void *)&Siemens_Shock_discrete_exp_Y, 0,
                sizeof(ExtY_Siemens_Shock_discrete_e_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  Siemens_Shock_discrete_exp_InitializeDataMapInfo
    ((&Siemens_Shock_discrete_exp_M), &Siemens_Shock_discrete_exp_B,
     &Siemens_Shock_discrete_exp_P, &Siemens_Shock_discrete_exp_DW);

  /* Start for Constant: '<S2>/h_Auflage' */
  Siemens_Shock_discrete_exp_B.h_Auflage =
    Siemens_Shock_discrete_exp_P.h_Auflage;

  /* InitializeConditions for DiscreteIntegrator: '<S2>/Discrete-Time Integrator2' */
  Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
    Siemens_Shock_discrete_exp_B.h_Auflage;
  if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE >=
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa) {
    Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
      Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator2_UpperSa;
  } else {
    if (Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE <=
        Siemens_Shock_discrete_exp_P.h_Auflage) {
      Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator2_DSTATE =
        Siemens_Shock_discrete_exp_P.h_Auflage;
    }
  }

  /* End of InitializeConditions for DiscreteIntegrator: '<S2>/Discrete-Time Integrator2' */

  /* InitializeConditions for DiscreteIntegrator: '<S2>/Discrete-Time Integrator' */
  Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_DSTATE =
    Siemens_Shock_discrete_exp_P.DiscreteTimeIntegrator_IC;
  Siemens_Shock_discrete_exp_DW.DiscreteTimeIntegrator_PrevRese = 2;
}

/* Model terminate function */
void Siemens_Shock_discrete_expModelClass::terminate()
{
  /* (no terminate code required) */
}

/* Constructor */
Siemens_Shock_discrete_expModelClass::Siemens_Shock_discrete_expModelClass()
{
  static const P_Siemens_Shock_discrete_exp_T Siemens_Shock_discrete_exp_P_temp =
  {
    /* Variable: J_Kugel
     * Referenced by: '<S2>/J'
     */
    0.0035000000000000005,

    /* Variable: dK
     * Referenced by: '<S2>/r_Kugel'
     */
    0.1,

    /* Variable: g
     * Referenced by: '<S2>/g'
     */
    9.81,

    /* Variable: h_Auflage
     * Referenced by:
     *   '<S2>/h_Auflage'
     *   '<S2>/Discrete-Time Integrator2'
     */
    1.3694384060045659,

    /* Variable: max_angle
     * Referenced by: '<S3>/Constant'
     */
    2.2689280275926285,

    /* Computed Parameter: DiscreteTimeIntegrator2_gainval
     * Referenced by: '<S2>/Discrete-Time Integrator2'
     */
    0.02,

    /* Expression: pi
     * Referenced by: '<S2>/Discrete-Time Integrator2'
     */
    3.1415926535897931,

    /* Computed Parameter: DiscreteTimeIntegrator_gainval
     * Referenced by: '<S2>/Discrete-Time Integrator'
     */
    0.02,

    /* Expression: 0
     * Referenced by: '<S2>/Discrete-Time Integrator'
     */
    0.0
  };                                   /* Modifiable parameters */

  /* Initialize tunable parameters */
  Siemens_Shock_discrete_exp_P = Siemens_Shock_discrete_exp_P_temp;
}

/* Destructor */
Siemens_Shock_discrete_expModelClass::~Siemens_Shock_discrete_expModelClass()
{
  /* Currently there is no destructor body generated.*/
}

/* Real-Time Model get method */
RT_MODEL_Siemens_Shock_discre_T * Siemens_Shock_discrete_expModelClass::getRTM()
{
  return (&Siemens_Shock_discrete_exp_M);
}
