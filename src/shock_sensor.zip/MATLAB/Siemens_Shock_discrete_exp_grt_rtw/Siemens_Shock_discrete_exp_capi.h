/*
 * Siemens_Shock_discrete_exp_capi.h
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.98
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Oct 29 11:03:15 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Siemens_Shock_discrete_exp_capi_h
#define RTW_HEADER_Siemens_Shock_discrete_exp_capi_h
#include "Siemens_Shock_discrete_exp.h"

extern void Siemens_Shock_discrete_exp_InitializeDataMapInfo
  (RT_MODEL_Siemens_Shock_discre_T *const Siemens_Shock_discrete_exp_M,
   B_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_B,
   P_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_P,
   DW_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_DW);

#endif                        /* RTW_HEADER_Siemens_Shock_discrete_exp_capi_h */

/* EOF: Siemens_Shock_discrete_exp_capi.h */
