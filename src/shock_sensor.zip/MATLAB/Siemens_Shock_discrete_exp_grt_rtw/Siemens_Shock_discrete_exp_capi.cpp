/*
 * Siemens_Shock_discrete_exp_capi.cpp
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.98
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Oct 29 11:03:15 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "Siemens_Shock_discrete_exp_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "Siemens_Shock_discrete_exp.h"
#include "Siemens_Shock_discrete_exp_capi.h"
#include "Siemens_Shock_discrete_exp_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 0, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/h_Auflage"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 1, TARGET_STRING("Siemens_Shock_discrete_exp/Gain"),
    TARGET_STRING("Gain"), 0, 0, 0 },

  { 2, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time Integrator"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 3, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time Integrator"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 4, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time Integrator2"),
    TARGET_STRING("gainval"), 0, 0, 0 },

  { 5, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time Integrator2"),
    TARGET_STRING("UpperSaturationLimit"), 0, 0, 0 },

  { 6, TARGET_STRING("Siemens_Shock_discrete_exp/Ballsensor Model/Switch"),
    TARGET_STRING("Threshold"), 0, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Block states information */
static rtwCAPI_States rtBlockStates[] = {
  /* addrMapIndex, contStateStartIndex, blockPath,
   * stateName, pathAlias, dWorkIndex, dataTypeIndex, dimIndex,
   * fixPtIdx, sTimeIndex, isContinuous, hierInfoIdx, flatElemIdx
   */
  { 7, -1, TARGET_STRING(
    "Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time\nIntegrator"),
    TARGET_STRING(""), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  { 8, -1, TARGET_STRING(
    "Siemens_Shock_discrete_exp/Ballsensor Model/Discrete-Time\nIntegrator2"),
    TARGET_STRING(""), "", 0, 0, 0, 0, 0, 0, -1, 0 },

  {
    0, -1, (NULL), (NULL), (NULL), 0, 0, 0, 0, 0, 0, -1, 0
  }
};

/* Tunable variable parameters */
static rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 9, TARGET_STRING("J_Kugel"), 0, 0, 0 },

  { 10, TARGET_STRING("dK"), 0, 0, 0 },

  { 11, TARGET_STRING("g"), 0, 0, 0 },

  { 12, TARGET_STRING("h_Auflage"), 0, 0, 0 },

  { 13, TARGET_STRING("max_angle"), 0, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Initialize Data Address */
static void Siemens_Shock_discrete_exp_InitializeDataAddr(void* dataAddr[],
  B_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_B,
  P_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_P,
  DW_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_DW)
{
  dataAddr[0] = (void*) (&Siemens_Shock_discrete_exp_B->h_Auflage);
  dataAddr[1] = (void*) (&Siemens_Shock_discrete_exp_P->Gain_Gain);
  dataAddr[2] = (void*)
    (&Siemens_Shock_discrete_exp_P->DiscreteTimeIntegrator_gainval);
  dataAddr[3] = (void*)
    (&Siemens_Shock_discrete_exp_P->DiscreteTimeIntegrator_IC);
  dataAddr[4] = (void*)
    (&Siemens_Shock_discrete_exp_P->DiscreteTimeIntegrator2_gainval);
  dataAddr[5] = (void*)
    (&Siemens_Shock_discrete_exp_P->DiscreteTimeIntegrator2_UpperSa);
  dataAddr[6] = (void*) (&Siemens_Shock_discrete_exp_P->Switch_Threshold);
  dataAddr[7] = (void*)
    (&Siemens_Shock_discrete_exp_DW->DiscreteTimeIntegrator_DSTATE);
  dataAddr[8] = (void*)
    (&Siemens_Shock_discrete_exp_DW->DiscreteTimeIntegrator2_DSTATE);
  dataAddr[9] = (void*) (&Siemens_Shock_discrete_exp_P->J_Kugel);
  dataAddr[10] = (void*) (&Siemens_Shock_discrete_exp_P->dK);
  dataAddr[11] = (void*) (&Siemens_Shock_discrete_exp_P->g);
  dataAddr[12] = (void*) (&Siemens_Shock_discrete_exp_P->h_Auflage);
  dataAddr[13] = (void*) (&Siemens_Shock_discrete_exp_P->max_angle);
}

#endif

/* Initialize Data Run-Time Dimension Buffer Address */
#ifndef HOST_CAPI_BUILD

static void Siemens_Shock_discrete_exp_InitializeVarDimsAddr(int32_T
  * vardimsAddr[])
{
  vardimsAddr[0] = (NULL);
}

#endif

#ifndef HOST_CAPI_BUILD

/* Initialize logging function pointers */
static void Siemens_Shock_discrete_exp_InitializeLoggingFunctions
  (RTWLoggingFcnPtr loggingPtrs[])
{
  loggingPtrs[0] = (NULL);
  loggingPtrs[1] = (NULL);
  loggingPtrs[2] = (NULL);
  loggingPtrs[3] = (NULL);
  loggingPtrs[4] = (NULL);
  loggingPtrs[5] = (NULL);
  loggingPtrs[6] = (NULL);
  loggingPtrs[7] = (NULL);
  loggingPtrs[8] = (NULL);
  loggingPtrs[9] = (NULL);
  loggingPtrs[10] = (NULL);
  loggingPtrs[11] = (NULL);
  loggingPtrs[12] = (NULL);
  loggingPtrs[13] = (NULL);
}

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1                                    /* 1 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.02, 0.0
};

/* Fixed Point Map */
static rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { static_cast<const void *>(&rtcapiStoredFloats[0]), static_cast<const void *>
    (&rtcapiStoredFloats[1]), 0, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 1,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 6,
    rtModelParameters, 5 },

  { rtBlockStates, 2 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 3951860563U,
    1344295725U,
    1187853557U,
    328908526U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  Siemens_Shock_discrete_exp_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void Siemens_Shock_discrete_exp_InitializeDataMapInfo
  (RT_MODEL_Siemens_Shock_discre_T *const Siemens_Shock_discrete_exp_M,
   B_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_B,
   P_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_P,
   DW_Siemens_Shock_discrete_exp_T *Siemens_Shock_discrete_exp_DW)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi,
    (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  Siemens_Shock_discrete_exp_InitializeDataAddr
    (Siemens_Shock_discrete_exp_M->DataMapInfo.dataAddress,
     Siemens_Shock_discrete_exp_B, Siemens_Shock_discrete_exp_P,
     Siemens_Shock_discrete_exp_DW);
  rtwCAPI_SetDataAddressMap(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi,
    Siemens_Shock_discrete_exp_M->DataMapInfo.dataAddress);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  Siemens_Shock_discrete_exp_InitializeVarDimsAddr
    (Siemens_Shock_discrete_exp_M->DataMapInfo.vardimsAddress);
  rtwCAPI_SetVarDimsAddressMap(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi,
    Siemens_Shock_discrete_exp_M->DataMapInfo.vardimsAddress);

  /* Set Instance specific path */
  rtwCAPI_SetPath(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetFullPath(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API logging function pointers into the Real-Time Model Data structure */
  Siemens_Shock_discrete_exp_InitializeLoggingFunctions
    (Siemens_Shock_discrete_exp_M->DataMapInfo.loggingPtrs);
  rtwCAPI_SetLoggingPtrs(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi,
    Siemens_Shock_discrete_exp_M->DataMapInfo.loggingPtrs);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi,
    (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(Siemens_Shock_discrete_exp_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void Siemens_Shock_discrete_exp_host_InitializeDataMapInfo
    (Siemens_Shock_discrete_exp_host_DataMapInfo_T *dataMap, const char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: Siemens_Shock_discrete_exp_capi.cpp */
