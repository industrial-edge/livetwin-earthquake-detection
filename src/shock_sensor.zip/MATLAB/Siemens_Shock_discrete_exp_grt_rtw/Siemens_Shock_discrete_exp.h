/*
 * Siemens_Shock_discrete_exp.h
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.98
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Oct 29 11:03:15 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Siemens_Shock_discrete_exp_h_
#define RTW_HEADER_Siemens_Shock_discrete_exp_h_
#include <math.h>
#include <string.h>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef Siemens_Shock_discrete_exp_COMMON_INCLUDES_
# define Siemens_Shock_discrete_exp_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                         /* Siemens_Shock_discrete_exp_COMMON_INCLUDES_ */

#include "Siemens_Shock_discrete_exp_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block signals (default storage) */
typedef struct {
  real_T h_Auflage;                    /* '<S2>/h_Auflage' */
} B_Siemens_Shock_discrete_exp_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T DiscreteTimeIntegrator2_DSTATE;/* '<S2>/Discrete-Time Integrator2' */
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S2>/Discrete-Time Integrator' */
  int8_T DiscreteTimeIntegrator2_PrevRes;/* '<S2>/Discrete-Time Integrator2' */
  int8_T DiscreteTimeIntegrator_PrevRese;/* '<S2>/Discrete-Time Integrator' */
} DW_Siemens_Shock_discrete_exp_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T Accelx;                       /* '<Root>/Accelx' */
  real_T Accely;                       /* '<Root>/Accely' */
} ExtU_Siemens_Shock_discrete_e_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T phi;                          /* '<Root>/phi' */
  uint8_T Schock;                      /* '<Root>/Schock' */
} ExtY_Siemens_Shock_discrete_e_T;

/* Parameters (default storage) */
struct P_Siemens_Shock_discrete_exp_T_ {
  real_T J_Kugel;                      /* Variable: J_Kugel
                                        * Referenced by: '<S2>/J'
                                        */
  real_T dK;                           /* Variable: dK
                                        * Referenced by: '<S2>/r_Kugel'
                                        */
  real_T g;                            /* Variable: g
                                        * Referenced by: '<S2>/g'
                                        */
  real_T h_Auflage;                    /* Variable: h_Auflage
                                        * Referenced by:
                                        *   '<S2>/h_Auflage'
                                        *   '<S2>/Discrete-Time Integrator2'
                                        */
  real_T max_angle;                    /* Variable: max_angle
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T DiscreteTimeIntegrator2_gainval;
                          /* Computed Parameter: DiscreteTimeIntegrator2_gainval
                           * Referenced by: '<S2>/Discrete-Time Integrator2'
                           */
  real_T DiscreteTimeIntegrator2_UpperSa;/* Expression: pi
                                          * Referenced by: '<S2>/Discrete-Time Integrator2'
                                          */
  real_T Gain_Gain;                    /* Expression: 180/pi
                                        * Referenced by: '<Root>/Gain'
                                        */
  real_T Switch_Threshold;             /* Expression: 1
                                        * Referenced by: '<S2>/Switch'
                                        */
  real_T DiscreteTimeIntegrator_gainval;
                           /* Computed Parameter: DiscreteTimeIntegrator_gainval
                            * Referenced by: '<S2>/Discrete-Time Integrator'
                            */
  real_T DiscreteTimeIntegrator_IC;    /* Expression: 0
                                        * Referenced by: '<S2>/Discrete-Time Integrator'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_Siemens_Shock_discret_T {
  const char_T *errorStatus;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[14];
    int32_T* vardimsAddress[14];
    RTWLoggingFcnPtr loggingPtrs[14];
  } DataMapInfo;
};

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  Siemens_Shock_discrete_exp_GetCAPIStaticMap(void);

/* Class declaration for model Siemens_Shock_discrete_exp */
class Siemens_Shock_discrete_expModelClass {
  /* public data and function members */
 public:
  /* External inputs */
  ExtU_Siemens_Shock_discrete_e_T Siemens_Shock_discrete_exp_U;

  /* External outputs */
  ExtY_Siemens_Shock_discrete_e_T Siemens_Shock_discrete_exp_Y;

  /* model initialize function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  Siemens_Shock_discrete_expModelClass();

  /* Destructor */
  ~Siemens_Shock_discrete_expModelClass();

  /* Real-Time Model get method */
  RT_MODEL_Siemens_Shock_discre_T * getRTM();

  /* private data and function members */
 private:
  /* Tunable parameters */
  static P_Siemens_Shock_discrete_exp_T Siemens_Shock_discrete_exp_P;

  /* Block signals */
  B_Siemens_Shock_discrete_exp_T Siemens_Shock_discrete_exp_B;

  /* Block states */
  DW_Siemens_Shock_discrete_exp_T Siemens_Shock_discrete_exp_DW;

  /* Real-Time Model */
  RT_MODEL_Siemens_Shock_discre_T Siemens_Shock_discrete_exp_M;
};

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Siemens_Shock_discrete_exp'
 * '<S1>'   : 'Siemens_Shock_discrete_exp/Accel_ges'
 * '<S2>'   : 'Siemens_Shock_discrete_exp/Ballsensor Model'
 * '<S3>'   : 'Siemens_Shock_discrete_exp/Ballsensor Model/Compare To Constant1'
 */
#endif                            /* RTW_HEADER_Siemens_Shock_discrete_exp_h_ */
