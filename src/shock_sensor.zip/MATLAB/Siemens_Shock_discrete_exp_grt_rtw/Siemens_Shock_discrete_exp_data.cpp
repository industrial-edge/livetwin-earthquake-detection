/*
 * Siemens_Shock_discrete_exp_data.cpp
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "Siemens_Shock_discrete_exp".
 *
 * Model version              : 1.98
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Oct 29 11:03:15 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86/Pentium
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Siemens_Shock_discrete_exp.h"
#include "Siemens_Shock_discrete_exp_private.h"

/* Block parameters (default storage) */
P_Siemens_Shock_discrete_exp_T Siemens_Shock_discrete_expModelClass::
  Siemens_Shock_discrete_exp_P = {
  /* Variable: J_Kugel
   * Referenced by: '<S2>/J'
   */
  0.0035000000000000005,

  /* Variable: dK
   * Referenced by: '<S2>/r_Kugel'
   */
  0.1,

  /* Variable: g
   * Referenced by: '<S2>/g'
   */
  9.81,

  /* Variable: h_Auflage
   * Referenced by:
   *   '<S2>/h_Auflage'
   *   '<S2>/Discrete-Time Integrator2'
   */
  1.3694384060045659,

  /* Variable: max_angle
   * Referenced by: '<S3>/Constant'
   */
  2.2689280275926285,

  /* Computed Parameter: DiscreteTimeIntegrator2_gainval
   * Referenced by: '<S2>/Discrete-Time Integrator2'
   */
  0.02,

  /* Expression: pi
   * Referenced by: '<S2>/Discrete-Time Integrator2'
   */
  3.1415926535897931,

  /* Expression: 180/pi
   * Referenced by: '<Root>/Gain'
   */
  57.295779513082323,

  /* Expression: 1
   * Referenced by: '<S2>/Switch'
   */
  1.0,

  /* Computed Parameter: DiscreteTimeIntegrator_gainval
   * Referenced by: '<S2>/Discrete-Time Integrator'
   */
  0.02,

  /* Expression: 0
   * Referenced by: '<S2>/Discrete-Time Integrator'
   */
  0.0
};
